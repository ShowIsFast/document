SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_seckill_goods
-- ----------------------------
DROP TABLE IF EXISTS `tb_seckill_goods`;
CREATE TABLE `tb_seckill_goods`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `goods_id` bigint NULL DEFAULT NULL COMMENT 'spu ID',
  `item_id` bigint NULL DEFAULT NULL COMMENT 'sku ID',
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '标题',
  `small_pic` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品图片',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '原价格',
  `cost_price` decimal(10, 2) NULL DEFAULT NULL COMMENT '秒杀价格',
  `seller_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商家ID',
  `create_time` datetime NULL DEFAULT NULL COMMENT '添加日期',
  `check_time` datetime NULL DEFAULT NULL COMMENT '审核日期',
  `status` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '审核状态',
  `start_time` datetime NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime NULL DEFAULT NULL COMMENT '结束时间',
  `num` int NULL DEFAULT NULL COMMENT '秒杀商品数',
  `stock_count` int NULL DEFAULT NULL COMMENT '剩余库存数',
  `introduction` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 56 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_seckill_goods
-- ----------------------------
INSERT INTO `tb_seckill_goods` VALUES (1, 149187842867960, 828744000, '秒杀精品女装', 'https://m.360buyimg.com/mobilecms/s720x720_jfs/t20800/271/2476006037/567266/1875299c/5b568051N0c089bef.jpg!q70.jpg.webp', 100.00, 0.01, 'mymall', '2023-07-20 16:37:16', '2023-07-21 16:37:16', '1', '2023-07-22 20:00:00', '2023-07-22 21:59:59', 10, 5, '1');
INSERT INTO `tb_seckill_goods` VALUES (2, 149187842867953, 3, '轻轻奶茶', 'http://sem.g3img.com/site/50021489/image/c2_20190411232047_66099.jpg', 10.00, 0.01, 'mymall', '2023-07-21 19:14:34', '2023-07-21 19:15:44', '1', '2023-07-22 22:00:00', '2023-07-22 23:59:59', 10, 5, '清仓打折');
INSERT INTO `tb_seckill_goods` VALUES (3, 12, 1, '运动鞋', 'http://i2.sinaimg.cn/ty/2014/0326/U5295P6DT20140326155117.jpg', 45.00, 0.01, 'mymall', '2023-07-18 19:14:37', '2023-07-20 19:15:48', '1', '2023-07-22 00:00:00', '2023-07-22 01:59:59', 11, 5, NULL);
INSERT INTO `tb_seckill_goods` VALUES (8, 1, 2, '拉杆箱', 'https://m.360buyimg.com/mobilecms/s720x720_jfs/t17386/123/1149702488/163904/69e3f45e/5abdabb5N3f3716d4.jpg!q70.jpg.webp', 4.00, 0.01, 'mymall', '2023-07-19 19:03:38', '2023-07-20 16:37:16', '1', '2023-07-22 20:00:00', '2023-07-22 21:59:59', 10, 2, '3');
INSERT INTO `tb_seckill_goods` VALUES (10, 10001, 1001, '纯牛奶', 'https://m.360buyimg.com/mobilecms/s720x720_jfs/t11458/47/1578777057/247729/85d27579/5a03c74eNdda3506e.jpg!q70.jpg.webp', 100.00, 0.01, 'mymall', '2023-07-15 17:40:05', '2023-07-18 17:40:22', '1', '2023-07-22 22:00:00', '2023-07-22 23:59:59', 10, 9, '测试秒杀');
INSERT INTO `tb_seckill_goods` VALUES (55, 250, 4, '羽绒服', 'http://img14.360buyimg.com/popWaterMark/g13/M03/0A/1D/rBEhU1Kmlr8IAAAAAATBCejgYvoAAGmMAC0zhIABMEh349.jpg', 100.00, 0.01, 'mymall', '2023-07-18 09:50:52', '2023-07-19 10:06:27', '1', '2023-07-22 00:00:00', '2023-07-22 01:59:59', 10, 10, '清仓');

-- ----------------------------
-- Table structure for tb_seckill_order
-- ----------------------------
DROP TABLE IF EXISTS `tb_seckill_order`;
CREATE TABLE `tb_seckill_order`  (
  `id` bigint NOT NULL COMMENT '主键',
  `seckill_id` bigint NULL DEFAULT NULL COMMENT '秒杀商品ID',
  `money` decimal(10, 2) NULL DEFAULT NULL COMMENT '支付金额',
  `user_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户',
  `seller_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商家',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `pay_time` datetime NULL DEFAULT NULL COMMENT '支付时间',
  `status` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '状态',
  `receiver_address` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货人地址',
  `receiver_mobile` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货人电话',
  `receiver` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货人',
  `transaction_id` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '交易流水',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_seckill_order
-- ----------------------------
INSERT INTO `tb_seckill_order` VALUES (1430094303798157312, 1, 0.01, 'zhiyi', 'qiandu', '2022-08-24 17:07:07', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1431177139473014784, 2, 0.01, 'zhiyi', 'yijia', '2022-08-27 16:49:55', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1431216515473137664, 1, 0.01, '18131254123', 'qiandu', '2022-08-27 19:26:23', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1431227052181348352, 2, 0.01, '18730284123', 'yijia', '2022-08-27 20:08:15', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1432556304839401472, 1, 0.01, '15551556578', 'qiandu', '2022-08-31 12:10:13', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1432600876093202432, 1, 0.01, '15551556578', 'qiandu', '2022-08-31 15:07:20', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1432606690283544576, 1, 0.01, 'zhiyi', 'qiandu', '2022-08-31 15:30:26', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1432628649587302400, 1, 0.01, 'zhiyi', 'qiandu', '2022-08-31 16:57:42', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1432635332397031424, 1, 0.01, '15512345678', 'qiandu', '2022-08-31 17:24:15', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1432635784496865280, 1, 0.01, '15512345678', 'qiandu', '2022-08-31 17:26:03', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1432637243170938880, 1, 0.01, '15512345678', 'qiandu', '2022-08-31 17:31:51', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1432638111643525120, 1, 0.01, '15512345678', 'qiandu', '2022-08-31 17:35:18', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1432638384151650304, 1, 0.01, '15512345678', 'qiandu', '2022-08-31 17:36:23', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1433046306144837632, 2, 0.01, '18730280709', 'yijia', '2022-09-01 20:37:19', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1434814909382844416, 3, 0.04, 'zhiyi', 'mymall', '2022-09-06 17:45:07', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1469805859829899264, 55, 0.02, 'zhiyi', 'mymall', '2022-12-12 07:06:39', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1474627891281190912, 1, 0.01, 'wzs', 'mymall', '2022-12-25 14:27:41', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1474639932763070464, 1, 0.01, 'wzs', 'mymall', '2022-12-25 15:15:32', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1474676693799198720, 2, 0.01, 'wzs', 'mymall', '2022-12-25 17:41:37', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1474678544737165312, 2, 0.01, 'wzs', 'mymall', '2022-12-25 17:48:58', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1474678913475207168, 2, 0.01, 'wzs', 'mymall', '2022-12-25 17:50:26', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1474679965683474432, 2, 0.01, 'wzs', 'mymall', '2022-12-25 17:54:37', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1474681565260996608, 2, 0.01, 'wzs', 'mymall', '2022-12-25 18:00:58', NULL, '0', NULL, NULL, NULL, NULL);
INSERT INTO `tb_seckill_order` VALUES (1476156634524999680, 8, 1.00, 'wzs', 'mymall', '2022-12-29 19:42:22', NULL, '0', NULL, NULL, NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
